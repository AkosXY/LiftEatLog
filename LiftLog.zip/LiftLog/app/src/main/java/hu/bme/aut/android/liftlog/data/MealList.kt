package hu.bme.aut.android.liftlog.data

data class MealList(
    val meals: List<Meal>
)